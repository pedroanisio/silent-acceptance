---
disclaimer:
  notice: >-
    No information within this document should be taken for granted.
    Any statement or premise not backed by a real logical definition
    or verifiable reference may be invalid, erroneous, or a hallucination.
---

# PALS's Law — Publication Checklist

Step-by-step instructions from artifact to published, citable work.
Check items off as you complete them.

---

## Phase 1: GitHub Repository (do this first)

- [ ] Create a new public repository (e.g., `pals-law`)
- [ ] Push all files from the release package:
      ```
      PALS_LAW-v1.5.4.md
      pals_law_schema.json
      pals_law_report.json
      pals_law_certificate.json
      README.md
      LICENSE
      CITATION.cff
      .gitignore
      .github/workflows/release.yml
      latex/pals_law.tex
      docs/index.html
      ```
- [ ] In `README.md` and `CITATION.cff`, replace `USERNAME` with your GitHub username
- [ ] In `docs/index.html`, replace `USERNAME` with your GitHub username
- [ ] Go to **Settings → Pages** and set source to `main` branch, `/docs` folder
  - This publishes the landing page at `https://<username>.github.io/pals-law/`
- [ ] Verify the landing page renders correctly (math, links, dark mode)
- [ ] Create a tag and push it:
      ```bash
      git tag -a v1.5.4 -m "PALS's Law v1.5.4"
      git push origin v1.5.4
      ```
  - This triggers the GitHub Actions release workflow
  - Note: the Zenodo auto-publish job is gated behind a `ZENODO_PUBLISH_ENABLED`
    variable — it won't fire until Phase 2 is complete

---

## Phase 2: Zenodo (DOI minting)

### Option A: Web UI (simplest)

- [ ] Go to [zenodo.org/deposit/new](https://zenodo.org/deposit/new)
- [ ] Upload the four core files:
      - `PALS_LAW-v1.5.4.md`
      - `pals_law_schema.json`
      - `pals_law_report.json`
      - `pals_law_certificate.json`
- [ ] Also upload `latex/pals_law.pdf` (the compiled preprint)
- [ ] Fill in metadata:
      - **Type:** Publication → Preprint
      - **Title:** PALS's Law: A Formal Specification of LLM Output Unreliability as an Architectural Invariant
      - **Authors:** de Luna e Silva, Pedro Anisio (add ORCID if you have one)
      - **Description:** (use the abstract from the LaTeX or README)
      - **License:** Creative Commons Attribution 4.0
      - **Keywords:** LLM, hallucination, verification, software engineering, PALS's Law
      - **Version:** 1.5.4
      - **Related identifiers:**
        - `10.1145/3618260.3649777` (references)
        - `https://arxiv.org/abs/2401.11817` (references)
- [ ] Click **Reserve DOI** — note the assigned DOI
- [ ] **Review** the preview page
- [ ] **Publish** — this mints the DOI and is irreversible for files
- [ ] Record the DOI: `10.5281/zenodo.XXXXXXX`

### Option B: SDK (automated)

- [ ] Create a Personal Access Token at [zenodo.org/account/settings/applications/tokens/new/](https://zenodo.org/account/settings/applications/tokens/new/)
  - Scopes: `deposit:write`, `deposit:actions`
- [ ] **Test first** on sandbox:
      ```bash
      cd pals-law  # your repo root
      ZENODO_SANDBOX=1 ZENODO_TOKEN=<sandbox-token> npx tsx examples/publish-pals-law.ts
      ```
- [ ] **Publish for real:**
      ```bash
      ZENODO_TOKEN=<real-token> npx tsx examples/publish-pals-law.ts
      ```
      Then uncomment the `publish` call in the script when ready.
- [ ] Record the DOI: `10.5281/zenodo.XXXXXXX`

### After Zenodo publication:

- [ ] Update `docs/index.html` — replace `zenodo.XXXXXXX` with the real DOI
- [ ] Update `README.md` citation block with the DOI
- [ ] Update `CITATION.cff` — add a `doi:` field
- [ ] Commit and push the DOI updates

### Enable CI auto-publish (optional, for future versions):

- [ ] In GitHub repo **Settings → Secrets and variables → Actions**:
  - Add secret `ZENODO_TOKEN` with your production token
  - Add variable `ZENODO_PUBLISH_ENABLED` = `true`
- [ ] Future `v*` tags will auto-publish to both GitHub Releases and Zenodo

---

## Phase 3: arXiv (optional, adds academic visibility)

- [ ] Determine if you need an endorsement:
  - Go to [arxiv.org/auth/endorse](https://arxiv.org/auth/endorse)
  - Check categories: `cs.SE` (primary), `cs.AI`, `cs.CL` (cross-list)
  - If you need one, ask a colleague with prior arXiv publications in `cs.SE`
    to endorse you, or try `cs.AI` which may have a lower bar
- [ ] In `latex/pals_law.tex`:
  - Add `\usepackage{lmodern}` and `\usepackage{microtype}` back
    (arXiv has full TeX Live)
  - Fill in your email on the `\author` line
  - Add your ORCID if desired
- [ ] Submit at [arxiv.org/submit](https://arxiv.org/submit):
  - Upload `pals_law.tex`
  - Primary category: `cs.SE`
  - Cross-list: `cs.AI`, `cs.CL`
  - Comments: "12 pages, 12 references, 4 theoretical foundations, 9-class error taxonomy"
  - Report-no: (leave blank unless institutional)
- [ ] Wait for moderation (typically 1–3 business days)
- [ ] Once live, record the arXiv ID: `XXXX.XXXXX`
- [ ] Update `docs/index.html` with the arXiv link
- [ ] Update `CITATION.cff` with `arxiv:` field
- [ ] Add a related identifier to the Zenodo record linking to the arXiv preprint

---

## Phase 4: Amplification (optional)

- [ ] Write a companion blog post explaining the law in plain language
  - Target: Dev.to, Hashnode, or personal blog
  - Focus on: the error taxonomy, the contract block, Corollary 5
  - Link to: GitHub, Zenodo DOI, arXiv
- [ ] Post on Hacker News (Show HN: ...)
- [ ] Post on relevant subreddits: r/MachineLearning, r/programming, r/software
- [ ] Tweet/post with the DOI link
- [ ] If you have a personal website, add a dedicated page linking to all venues

---

## Reference: What goes where

| Venue | What it does | Permanence |
|-------|-------------|------------|
| **GitHub** | Practitioner distribution, issue tracking, version control | Permanent (as long as the repo exists) |
| **Zenodo** | DOI minting, academic discoverability, archival | Permanent (CERN-backed, DOI registered) |
| **arXiv** | Academic visibility, indexing, preprint record | Permanent (arXiv doesn't delete) |
| **Landing page** | Public-facing explanation, links to all venues | Depends on GitHub Pages / hosting |
| **Blog/social** | Initial awareness, discussion | Ephemeral (drives traffic to permanent venues) |
